#!/bin/env python
"""
Simulation Class Demo
=====================

This script shows you how to use the Simulation class to setup
``specfem3d_globe`` and subsequent database files.

"""
# sphinx_gallery_thumbnail_number = 1
# sphinx_gallery_dummy_images = 1

# %%

print('Under construction.')
